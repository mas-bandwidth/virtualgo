#ifndef CONFIG_H
#define CONFIG_H

#define LETTERBOX
#define WIDESCREEN
#define SHADOWS
//#define MULTISAMPLING
//#define MULTITHREADED
#define THREAD_STACK_SIZE 8 * 1024 * 1024

//#define USE_SECONDARY_DISPLAY_IF_EXISTS
//#define DEBUG_SHADOW_VOLUMES
//#define FRUSTUM_CULLING
//#define DISCOVER_KEY_CODES

#endif
