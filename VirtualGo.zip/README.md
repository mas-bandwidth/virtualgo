virtualgo
=========

a networked physics simulation of a go board and stones